import React, { useState } from 'react';
import './slot.css'; // Import the CSS file

function Slot() {
  const [isLoginPageVisible, setIsLoginPageVisible] = useState(false);
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');

  const handleStudentClick = () => {
    setIsLoginPageVisible(true);
  };

  const handleFacultyClick = () => {
    setIsLoginPageVisible(true);
  };

  const handleLogin = () => {
    console.log('Login clicked');
    console.log('User ID:', userId);
    console.log('Password:', password);
    // Add your login functionality here

    // Redirect to the next page after login
    setIsLoginPageVisible(false);
  };

  return (
    <div className="button-container">
      {!isLoginPageVisible && (
        <button className="button" onClick={handleStudentClick}>
          Student
        </button>
      )}
      {!isLoginPageVisible && (
        <button className="button" onClick={handleFacultyClick}>
          Faculty
        </button>
      )}
      {isLoginPageVisible && (
        <div>
          <label htmlFor="userId">User ID:</label>
          <input
            type="text"
            id="userId"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
          <br />
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <br />
          <button onClick={handleLogin}>Login</button>
        </div>
      )}
    </div>
  );
}

export default Slot;
