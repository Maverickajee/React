// StudentPage.js
import React from 'react';

function StudentPage() {
  return (
    <div>
      <label>Roll No:</label>
      <input type="text" />
      <br />
      <label>Password:</label>
      <input type="password" />
      <br />
      <button>Submit</button>
    </div>
  );
}

export default StudentPage;
