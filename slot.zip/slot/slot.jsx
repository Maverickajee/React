import React, { useState } from "react";

function StudentPage({ onLogin }) {
  const [rollNo, setRollNo] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    // Perform your login logic here
    if (rollNo === "123" && password === "123") {
      onLogin(rollNo); // Pass the rollNo to the parent component
    } else {
      console.log("Invalid credentials"); // Display an error message or handle accordingly
    }
  };

  return (
    <div>
      <label htmlFor="rollNo">Roll No:</label>
      <input
        type="text"
        id="rollNo"
        value={rollNo}
        onChange={(e) => setRollNo(e.target.value)}
      />
      <br />
      <label htmlFor="password">Password:</label>
      <input
        type="password"
        id="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <br />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

function NamePage({ rollNo }) {
  const [name, setName] = useState("");

  const handleNameSubmit = () => {
    // Perform your name submission logic here
    console.log("Name submitted:", name);
  };

  return (
    <div>
      <label htmlFor="name">Name:</label>
      <input
        type="text"
        id="name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <label htmlFor="rollno">Roll No:</label>
      <input type="text" />
      <br />
      <button onClick={handleNameSubmit}>Submit</button>
    </div>
  );
}

function FacultyPage() {
  return <div></div>;
}

function Slot() {
  const [showStudentPage, setShowStudentPage] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRollNo, setUserRollNo] = useState("");

  const handleStudentClick = () => {
    setShowStudentPage(true);
  };

  const handleLogin = (rollNo) => {
    setIsLoggedIn(true);
    setUserRollNo(rollNo);
  };

  return (
    <div>
      {!isLoggedIn ? (
        <>
          <button onClick={handleStudentClick}>Faculty</button>
          <button onClick={() => setIsLoggedIn(true)}>Student</button>
        </>
      ) : (
        <>
          {showStudentPage ? (
            <>
              {userRollNo ? (
                <NamePage rollNo={userRollNo} />
              ) : (
                <StudentPage onLogin={handleLogin} />
              )}
            </>
          ) : (
            <FacultyPage />
          )}
        </>
      )}
    </div>
  );
}

export default Slot;
