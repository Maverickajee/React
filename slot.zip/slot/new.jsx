import React, { useState } from "react";

function StudentPage() {
  return (
    <div>
      <label htmlFor="rollno">Roll No:</label>
      <input type="text" id="rollNo" />
      <label htmlFor="password">Password:</label>
      <input type="password" id="pass" />
      <button>Submit</button>
    </div>
  );
}

function FacultyPage() {
  return (
    <div>
      <label htmlFor="id">Faculty Id:</label>
      <input type="text" id="rollNo" />
      <label htmlFor="password">Password:</label>
      <input type="password" id="pass" />
      <button>Submit</button>
    </div>
  );
}

function Slot() {
  const [showStudentPage, setShowStudentPage] = useState(false);
  const [showFacultyPage, setShowfacultyPage] = useState(false);
  const handleStudentClick = () => {
    setShowStudentPage(true);
  };

  const handleFacultyClick = () => {
    setShowfacultyPage(true);
  };

  return (
    <div>
      {!showStudentPage && !showFacultyPage && (
        <>
          <button onClick={handleStudentClick}>Student</button>
          <button onClick={handleFacultyClick}>Faculty</button>
        </>
      )}
      {showStudentPage && <StudentPage />}
      {showFacultyPage && <FacultyPage />}
    </div>
  );
}
export default Slot;
