import React, { useState } from 'react'
//import './SalemCSS.css'

function Salem() {

  const [item1,setItem1] = useState(10) 
  const [item2, setitem2] = useState(15) 
  const [count,setCount] = useState(0)
  const [item1Over,setitem1Over]=useState(false)
  const [item2Over,setitem2Over]=useState(false)


  const handleClickItem1 = (e) =>
  {
     e.preventDefault()

     if(item1 > 0)
     {
     setItem1((prevstate) => prevstate-1)
     setCount((prev)=> prev+1)
     }
     else setitem1Over(true)
     
  }
  const handleClickItem2 = (e) =>
  {
     e.preventDefault()
     if(item2 > 0)
     {
      setitem2((prevstate) => prevstate-1)
      setCount((prev)=> prev+1)
     }
     else setitem2Over(true)
  }
  
  return (
    <div className='center'>
   <div className="container">
      <h3 className="title">Salem Cafe</h3>

      <div className="item">
        <p>Blueberry Muffins</p>
        <p className="item-count">No of items: {item1}</p>
        {item1Over && <p className="item-over">Item over</p>}
        <button className="button" onClick={handleClickItem1}>
          Add Blueberry Muffins
        </button>
      </div>

      <div className="item">
        <p>Chocolate Chip Cookies</p>
        <p className="item-count">No of items: {item2}</p>
        {item2Over && <p className="item-over">Item over</p>}
        <button className="button" onClick={handleClickItem2}>
          Add Chocolate Chip Cookies
        </button>
      </div>

      <p>Total item purchased: {count}</p>
    </div>
  

   </div>
  )
}

export default Salem